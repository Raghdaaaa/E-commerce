package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CategoryP extends Page {

    public CategoryP(WebDriver driver) {
        super(driver);
    }

    public By popularTags(){
        return By.xpath("//div[@class='tags']//li//a");
    }

}
