package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductP extends Page {

    public ProductP(WebDriver driver) {
        super(driver);
    }

    public By productTagsList(){
        return By.xpath(".//div[@class=\"product-tags-list\"]//li/a");
    }
}
